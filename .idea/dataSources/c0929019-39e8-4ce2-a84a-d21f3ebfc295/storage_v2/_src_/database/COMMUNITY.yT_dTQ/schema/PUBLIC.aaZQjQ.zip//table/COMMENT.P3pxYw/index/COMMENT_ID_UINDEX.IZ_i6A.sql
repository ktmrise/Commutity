create unique index COMMENT_ID_UINDEX
    on COMMENT (ID);

